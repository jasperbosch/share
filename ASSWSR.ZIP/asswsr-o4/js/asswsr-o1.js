PointText.prototype.mirror = function (orientation) {
    var axis = {
        'horizontal': {
            'x': -1,
            'y': 1
        },
        'vertical': {
            'x': 1,
            'y': -1
        }
    };
    return this.scale(axis[orientation].x, axis[orientation].y);
};

var strokeWidth = 5;
var fontSize = 300;
// var tekst = 'a';
var tekst = 'autisme';
var dots = '. . . . . .';
var flipOn = 260;


var dots1 = new paper.PointText();
dots1.content = dots;
dots1.fontSize = 270;
dots1.position = new Point(600, -20);
dots1.strokeColor = new Color(0, 0, 0);
dots1.strokeWidth = strokeWidth;
dots1.fillColor = new Color(256, 256, 256);


var tekst1 = new paper.PointText();
tekst1.content = tekst;
tekst1.fontSize = fontSize;
tekst1.position = new Point(600, 250);
tekst1.strokeColor = new Color(0, 0, 0);
tekst1.strokeWidth = strokeWidth;
tekst1.fillColor = new Color(256, 256, 256);

var myPath;

var cursor = Path.Circle({
    center: new Point(10, 10),
    strokeColor: 'black',
    fillColor: 'gray',
    radius: 3,
});

function onMouseMove(event) {
    var y = flipOn + (flipOn - event.point.y);
    cursor.position = new Point(event.point.x, y);
}

function onMouseDown(event) {
    myPath = new Path();
    myPath.strokeColor = 'black';
    myPath.strokeWidth = 5;
}

function onMouseDrag(event) {
    var y = flipOn + (flipOn - event.point.y);
    myPath.add(event.point.x, y);
}
